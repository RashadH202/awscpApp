import json
import uuid

question_bank = []
high_scores = []

def find_question_by_id(question_id):
    for question in question_bank:
        if question['id'] == question_id:
            return question
    return None

def lambda_handler(event, context):
    method = event['httpMethod']
    path = event['path']

    if path == '/questions':
        if method == 'POST':
            return add_question(event)
        elif method == 'GET':
            return get_questions()
    elif path.startswith('/questions/'):
        question_id = path.split('/')[-1]
        if method == 'GET':
            return get_question(question_id)
        elif method == 'PUT':
            return update_question(question_id, event)
        elif method == 'DELETE':
            return delete_question(question_id)
    elif path == '/highscores':
        if method == 'GET':
            return get_high_scores()
        elif method == 'POST':
            return add_high_score(event)
    elif path == '/status':
        if method == 'GET':
            return get_status()
    
    return {
        'statusCode': 404,
        'body': json.dumps({'message': 'Not Found'})
    }

def add_question(event):
    data = json.loads(event['body'])
    new_question_id = str(uuid.uuid4())
    new_question = {
        'id': new_question_id,
        'question': data['question'],
        'choices': data['choices'],
        'correct_answer': data['correct_answer']
    }
    question_bank.append(new_question)
    return {
        'statusCode': 201,
        'body': json.dumps({'message': 'Question added successfully', 'question_id': new_question_id})
    }

def get_questions():
    return {
        'statusCode': 200,
        'body': json.dumps({'questions': question_bank})
    }

def get_question(question_id):
    question = find_question_by_id(question_id)
    if question:
        return {
            'statusCode': 200,
            'body': json.dumps({'question': question})
        }
    else:
        return {
            'statusCode': 404,
            'body': json.dumps({'message': 'Question not found'})
        }

def update_question(question_id, event):
    question = find_question_by_id(question_id)
    if question:
        data = json.loads(event['body'])
        question['question'] = data['question']
        question['choices'] = data['choices']
        question['correct_answer'] = data['correct_answer']
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Question updated successfully'})
        }
    else:
        return {
            'statusCode': 404,
            'body': json.dumps({'message': 'Question not found'})
        }

def delete_question(question_id):
    question = find_question_by_id(question_id)
    if question:
        question_bank.remove(question)
        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Question deleted successfully'})
        }
    else:
        return {
            'statusCode': 404,
            'body': json.dumps({'message': 'Question not found'})
        }

def get_high_scores():
    return {
        'statusCode': 200,
        'body': json.dumps({'highScores': high_scores})
    }

def add_high_score(event):
    data = json.loads(event['body'])
    high_scores.append({
        'score': data['score'],
        'timeFinished': data['timeFinished'],
        'numberOfQuestions': data['numberOfQuestions']
    })
    return {
        'statusCode': 201,
        'body': json.dumps({'message': 'High score added successfully'})
    }

def get_status():
    return {
        'statusCode': 200,
        'body': json.dumps({'status': 'Server is running'})
    }
